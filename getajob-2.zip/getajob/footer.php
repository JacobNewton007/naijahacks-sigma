		</div>
		<footer>
			<div><span>&copy; 2019 GetAJob powered by </span><a href="https://www.loftywebtech.com.ng">loftywebtech</a></div>
		</footer>
	</div>
</body>
</html>