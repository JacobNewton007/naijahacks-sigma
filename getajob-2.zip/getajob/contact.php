<?php
	include "header.php";
?>

<div class="skill-page page">
	<div class="welcome">
		<h4>Contact us</h4>
		<p>
			You can contact us via our social media platforms:
			<br />
			facebook: wwww.facebook.com/getajob
			<br />
			twitter: @getajob

			<br />
			<br />

			Tel 1: 09058689321
			<br />
			Tel 2: 08062790134

			<br />
			<br />

			Email: support@getajob.com
		</p>
	</div>
</div>

<?php
	include "footer.php";
?>			