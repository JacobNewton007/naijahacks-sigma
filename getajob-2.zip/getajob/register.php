<!DOCTYPE html>
<html>
<head>
	<title>GetAJob</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="form-wrapper">
		<form class="login-form">
			<span class="form-title">register</span>
			<p><input type="text" name="firstname" placeholder="firstname"></p>
			<p><input type="text" name="lastname" placeholder="lastname"></p>
			<p><input type="text" name="phone" placeholder="phone"></p>
			<p><input type="text" name="email" placeholder="email"></p>
			<p><input type="text" name="username" placeholder="username"></p>
			<p><input type="password" name="password" placeholder="password"></p>
			<p class="submit"><span>got an account? <a href="login.php">login</a></span><button type="submit" name="login">login</button></p>
		</form>
	</div>
</body>