<?php
	include "header.php";
?>

<div class="skill-page page">
	<div class="welcome">
		<h4>About Us</h4>
		<p>
			GetAJob is an online platform created to alleviate unemployment. 
			We exist to empower youths to by providing them with services 
			through which they could learn new skills and use this skills 
			to earn money.
		</p>
	</div>
</div>

<?php
	include "footer.php";
?>			