<!DOCTYPE html>
<html>
<head>
	<title>GetAJob</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="form-wrapper">
		<form class="login-form">
			<span class="form-title">login</span>
			<p><input type="text" name="username" placeholder="username"></p>
			<p><input type="password" name="password" placeholder="password"></p>
			<p class="submit"><span>new here? <a href="register.php">register</a></span><button type="submit" name="login">login</button></p>
		</form>
	</div>
</body>